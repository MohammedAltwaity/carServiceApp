﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLDGY0
{
    internal class StateOfTheWorksheetRegistration
    {


        public static int numberOfWorksheets = 0;
        public static int numberOfWork = 0;
        public static decimal materialCost = 0;
        public static decimal serviceCost = 0;
        public static decimal totalToPay = 0;
    }
}
